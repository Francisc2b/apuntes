
package com.mybank.prueba;

import com.mybank.domain.Account;
import com.mybank.domain.Customer;


public class TestCustomer {
    
    public static void main(String[] args) {
        
        /*
          Creo un nuevo objeto Customer cuya var de referencia
          se llamará cliente.
          Al crearla con este constructor, además de inicializar
          nombre y apellidos, crea medinte un new un nuevo objeto
          Account con saldo 0.0
        */
        Customer cliente = new Customer("Laura","Roca"); 
        System.out.println("....");
        
        System.out.println("... Datos del nuevo cliente");
        System.out.println("Nombre: " + cliente.getFirstName() + 
                " " + cliente.getLastName() );
        System.out.println("Saldo actual: " + cliente.getAccount().getBalance());
        
        //ingreso 200 euros
        System.out.println("ingreso 200");
        cliente.getAccount().deposit(200);
        //saco  120
        System.out.println("saco 120");
        cliente.getAccount().withdraw(120);
        //muestro saldo actual
        System.out.println("Saldo actual: " + cliente.getAccount().getBalance());
        
        // quier cambiar de cuenta bancaria
        
        Account nueva = new Account(1000);
        cliente.setAccount(nueva);
        
        
    }//fin main
    
}
