package com.mybank.prueba;

import com.mybank.dominio.Account;


public class TestAccount2 {
    
    //  psvm  tabulador
    public static void main(String[] args) {
        
        
        Account c = new Account(200);
        
        Account cuenta = new Account(400);
       // cuenta.balance = -20;
        
        System.out.println(" saldo " + cuenta.getBalance());
        
        System.out.println("... ingreso 100");
        cuenta.deposit(100);  
        
        System.out.println(" cuenta es " 
                + cuenta );  
                      //cuenta es Account@7852e922
                     // cuenta es Account{balance=400.0}
        //espero ver 500
        
        System.out.println("... ingreso -50");
        cuenta.deposit(-50);
        //espero ver 500 / no hay ingreso 
        System.out.println("cuenta ahora es " 
                + cuenta);
        
        
        //PRUEBA PARA WITHDRAW
        
        //1. extraer importe negativo
        
        double necesito = -30;
        cuenta.withdraw(necesito);
        
        //salida esperada es : 500 y un "Atención"
        System.out.println(cuenta);
        
        //2. extraer importe saldo suficiente
        necesito = 100;
        //salida esperadoa  : balance 400
        cuenta.withdraw(necesito);
        System.out.println(cuenta);
        
        //3. extraer importe sin saldo sufic
         necesito = 450;
         //dato partida  balance 400
        //salida esperado  : balance 400  y un Atención
        cuenta.withdraw(necesito);
        System.out.println(cuenta);
        
        
        
    }
    
}
