
package com.bank.excepciones;

public class BankException extends Exception{

    public BankException(String string) {
        super(string);
    }
    
}
