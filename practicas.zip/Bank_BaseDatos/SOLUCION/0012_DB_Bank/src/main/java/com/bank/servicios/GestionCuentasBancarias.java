package com.bank.servicios;

import com.bank.servicios.interfaces.GestionCuentasBancariasInterface;
import com.bank.dominio.CuentaBancaria;
import com.bank.excepciones.BankException;
import com.db.PoolConexiones;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class GestionCuentasBancarias implements GestionCuentasBancariasInterface {

    private static final String SELECT_GET_CUENTAS_BANCARIAS_CLIENTE
            = "SELECT ID_CUENTA, IBAN, SALDO, ID_CLIENTE "
            + "FROM CUENTAS_BANCARIAS "
            + "WHERE ID_CLIENTE = ?";
    
    private static final String INSERT_CUENTA_BANCARIA = "INSERT INTO CUENTAS_BANCARIAS"
            + "(ID_CUENTA, IBAN, SALDO, ID_CLIENTE) "
            + "VALUES (?,?,?,?)";
    
    private static final String MAX_ID_CUENTA_BANCARIA = "SELECT MAX(ID_CUENTA) "
            + "FROM CUENTAS_BANCARIAS";

    private static final String UPDATE_SALDO_CUENTA_BANCARIA_POR_IBAN = "UPDATE CUENTAS_BANCARIAS "
            + "SET SALDO = SALDO + ? "
            + "WHERE ID_CUENTA = ?";
    
    private static final String SELECT_GET_CUENTA_BANCARIA_POR_ID = 
              "SELECT ID_CUENTA, IBAN, SALDO, ID_CLIENTE "
            + "FROM CUENTAS_BANCARIAS "
            + "WHERE ID_CUENTA = ?";

    @Override
    public List<CuentaBancaria> getCuentasBancariasPorCliente(int idCliente) throws BankException, SQLException {
        List<CuentaBancaria> cuentas = new ArrayList<CuentaBancaria>();
        Connection con = PoolConexiones.getConexionLibre();

        PreparedStatement ps = con.prepareStatement(SELECT_GET_CUENTAS_BANCARIAS_CLIENTE);
        ps.setInt(1, idCliente);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            CuentaBancaria c = new CuentaBancaria();
            c.setIdCuenta(rs.getInt("ID_CUENTA"));
            c.setIban(rs.getString("IBAN"));
            c.setSaldo(rs.getDouble("SALDO"));
            c.setIdCliente(rs.getInt("ID_CLIENTE"));
            cuentas.add(c);
        }
        PoolConexiones.liberaConexion(con);
        return cuentas;
    }

    @Override
    public void altaNuevaCuenta(int idCliente, CuentaBancaria cuenta) throws BankException, SQLException {

        Connection con = PoolConexiones.getConexionLibre();
        try {
            //obtener el último id de cuenta bancaria 
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(MAX_ID_CUENTA_BANCARIA);
            int nuevoId = 1;
            if (rs.next()) {
                nuevoId = rs.getInt(1) + 1;
            }
            System.out.printf("Nuevo Id %d", nuevoId);

            PreparedStatement ps = con.prepareStatement(INSERT_CUENTA_BANCARIA);
            ps.setInt(1, nuevoId);
            ps.setString(2, cuenta.getIban());
            ps.setDouble(3, cuenta.getSaldo());
            ps.setInt(4, idCliente);
            ps.executeUpdate();
        } finally {
            PoolConexiones.liberaConexion(con);
        }
    }

    @Override
    public void ingresar(int idCuenta, double importe) throws BankException, SQLException {

        //1. validar importe > 0
        if (importe <= 0) {
            throw new BankException("No se hizo el ingreso. Debe indicar un importe mayor a 0. ");
        }

        Connection con = PoolConexiones.getConexionLibre();
        try {
            PreparedStatement ps = con.prepareStatement(UPDATE_SALDO_CUENTA_BANCARIA_POR_IBAN);
            ps.setDouble(1, importe);
            ps.setInt(2, idCuenta);
            int filas = ps.executeUpdate();
            if (filas == 0) {
                throw new BankException("No se ha hecho el ingreso. La cuenta no existe");
            }
        } finally {
            PoolConexiones.liberaConexion(con);
        }
    }

    @Override
    public void sacar(int idCuenta, double importe) throws BankException, SQLException {
    //1. validar importe > 0
        if (importe <= 0) {
            throw new BankException("No se hizo el reintegro. Debe indicar un importe mayor a 0. ");
        }

        Connection con = PoolConexiones.getConexionLibre();

        try {
            //Ver si hay saldo suficiente
            PreparedStatement ps = con.prepareStatement(SELECT_GET_CUENTA_BANCARIA_POR_ID);
            ps.setInt(1, idCuenta);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                double saldo = rs.getDouble("SALDO");
                if(saldo < importe){
                    throw new BankException("No se ha realizado en integro. Saldo insuficiente");
                }
            }else{
                throw new BankException("No se ha realizado el integro. La cuenta no existe");
            }
            
            PreparedStatement ps2 = con.prepareStatement(UPDATE_SALDO_CUENTA_BANCARIA_POR_IBAN);
            ps2.setDouble(1, -importe);
            ps2.setInt(2, idCuenta);
            int filas = ps2.executeUpdate();
            
        } finally {
            PoolConexiones.liberaConexion(con);
        }
    }

    public static void main(String[] args) {
        try {
            GestionCuentasBancarias gcb = new GestionCuentasBancarias();
           // gcb.altaNuevaCuenta(2, new CuentaBancaria(0, "IN7585555", 3000.0, 2));

          // gcb.ingresar(5, 100);
          
           gcb.sacar(5, 4000);
           
        } catch (BankException ex) {
            Logger.getLogger(GestionCuentasBancarias.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(GestionCuentasBancarias.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void hacerTransferencia(String ibanOrigen, String ibanDestino, double importe) throws BankException, SQLException {
        //obtener conexión  a la bd CofeeShop
        Connection con = PoolConexiones.getConexionLibre();
        try{
            con.setAutoCommit(false);  //desactivo la autoconfirmacion 
            //2 UPDATE
            String updateQuery = "UPDATE CUENTAS_BANCARIAS "
                    + "SET SALDO = SALDO + ? "
                    + "WHERE IBAN LIKE ?";
            PreparedStatement pst = con.prepareStatement(updateQuery);
            
             // CUENTA ORIGEN  -- SACAR DINERO
            pst.setDouble(1, - importe);
            pst.setString(2, ibanOrigen);
            pst.executeUpdate();
            
            // CUENTA DESTINO - INGRESAR DINERO
            pst.setDouble(1, + importe);
            pst.setString(2, ibanDestino);
            pst.executeUpdate();
            
            con.commit();
        }catch(SQLException e){
            con.rollback();
            throw new BankException("No se pudo hacer la transferencia. Error de BD " 
                    + e.getMessage());
        }finally{
            PoolConexiones.liberaConexion(con);
        }
    
    }

   
    
    

}
